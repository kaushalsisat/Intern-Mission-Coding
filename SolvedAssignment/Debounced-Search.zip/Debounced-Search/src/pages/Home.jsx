import React, { useState } from "react";
import SearchBar from "../components/SearchBar";
import RecipeList from "../components/RecipeList";
import RecipeDetails from "../components/RecipeDetails";

const Home = () => {
  const [recipes, setRecipes] = useState([]);
  const [selectedRecipe, setSelectedRecipe] = useState(null);

  return (
    <div className="flex flex-col items-center p-4 min-h-screen bg-gray-200 font-serif">
      {/* Show heading only when searching */}
      {!selectedRecipe && <h1 className="text-2xl font-bold mb-4 p-2 bg-yellow-600 rounded text-white">Search any Recipes</h1>}

      {!selectedRecipe ? (
        <>
          <SearchBar onRecipesFetched={setRecipes} />
          <RecipeList recipes={recipes} onSelectRecipe={setSelectedRecipe} />
        </>
      ) : (
        <RecipeDetails recipe={selectedRecipe} onBack={() => setSelectedRecipe(null)} />
      )}
    </div>
  );
};

export default Home;


