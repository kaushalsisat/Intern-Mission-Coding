import React from "react";

const RecipeList = ({ recipes, onSelectRecipe }) => {
    return (
      <div className="w-full max-w-md mx-auto mt-4">
        {recipes.length > 0 ? (
          <ul className="space-y-2">
            {recipes.map((recipe) => (
              <li
                key={recipe.id}
                className="p-3 border rounded-lg shadow-md bg-white cursor-pointer hover:bg-gray-200"
                onClick={() => onSelectRecipe(recipe)}
              >
                <h3 className="text-lg font-semibold">{recipe.name}</h3>
                <p className="text-sm text-gray-700">{recipe.description}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-center text-gray-500 mt-2">No recipes found.</p>
        )}
      </div>
    );
  };
  
  export default RecipeList;
  