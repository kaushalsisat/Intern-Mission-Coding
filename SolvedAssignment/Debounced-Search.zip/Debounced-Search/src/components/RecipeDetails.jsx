import React from "react";

const RecipeDetails = ({ recipe, onBack }) => {
  if (!recipe) return null;

  return (
    <div className="max-w-3xl mx-auto p-6 border border-gray-400 rounded-lg shadow-xl bg-white mt-4">
      {/* Back Button */}
      <button
        className="mb-4 text-white bg-blue-600 rounded px-4 py-2 hover:bg-blue-800"
        onClick={onBack}
      >
        ← Back
      </button>

      {/* Recipe Image */}
      <img
        src={recipe.image || "https://via.placeholder.com/600"}
        alt={recipe.name}
        className="w-full h-64 object-cover rounded-lg"
      />

      {/* Recipe Title */}
      <h2 className="text-3xl font-bold mt-4">{recipe.name}</h2>

      {/* Recipe Info - Rating, Reviews, Difficulty */}
      <div className="flex flex-wrap justify-between items-center mt-3 mb-3 text-gray-700">
        <span className="bg-yellow-100 text-black px-3 py-1 rounded-md">
          ⭐ {recipe.rating || "N/A"} / 5
        </span>
        <span>{recipe.reviewCount || 0} Reviews</span>
        <span className="bg-blue-300 px-3 py-1 rounded-md">
          {recipe.difficulty || "Unknown"}
        </span>
      </div>

      {/* Cuisine, Calories & Servings */}
      <div className="mt-4 flex flex-wrap gap-4 text-gray-600">
        <span className="bg-green-200 px-3 py-1 rounded-md">🍽 {recipe.cuisine} Cuisine</span>
        <span className="bg-red-200 px-3 py-1 rounded-md">🔥 {recipe.caloriesPerServing} Calories</span>
        <span className="bg-purple-200 px-3 py-1 rounded-md">👥 Servings: {recipe.servings}</span>
      </div>

      {/* Cooking & Prep Time */}
      <div className="mt-4 flex flex-wrap gap-4 text-gray-600">
        <span className="bg-orange-200 px-3 py-1 rounded-md">⏳ Prep: {recipe.prepTimeMinutes} mins</span>
        <span className="bg-blue-200 px-3 py-1 rounded-md">🍳 Cook: {recipe.cookTimeMinutes} mins</span>
      </div>

      {/* Description */}
      <p className="text-gray-700 mt-4">{recipe.description}</p>

      {/* Instructions */}
      <h3 className="text-xl font-semibold mt-4">Instructions:</h3>
      <ol className="list-decimal pl-6 text-gray-600 mt-2 space-y-1">
        {recipe.instructions.map((step, index) => (
          <li key={index}>{step}</li>
        ))}
      </ol>

      {/* Tags */}
      <h3 className="text-xl font-semibold mt-4">Tags:</h3>
      <div className="flex flex-wrap gap-2 mt-2">
        {recipe.tags.map((tag, index) => (
          <span key={index} className="bg-gray-300 px-3 py-1 rounded-md text-gray-800">
            #{tag}
          </span>
        ))}
      </div>

      {/* Meal Type */}
      <h3 className="text-xl font-semibold mt-4">Meal Type:</h3>
      <div className="flex flex-wrap gap-2 mt-2">
        {recipe.mealType.map((type, index) => (
          <span key={index} className="bg-yellow-200 px-3 py-1 rounded-md text-gray-800">
            {type}
          </span>
        ))}
      </div>
    </div>
  );
};

export default RecipeDetails;
