import React from "react";
import { useState, useEffect, useRef } from "react";

const SearchBar = ({ onRecipesFetched }) => {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const debounceTimeout = useRef(null);

  useEffect(() => {
    if (!query.trim()) {
      onRecipesFetched([]); // Clear results if input is empty
      return;
    }

    setLoading(true);

    // Debouncing logic
    if (debounceTimeout.current) {
      clearTimeout(debounceTimeout.current);
    }

    debounceTimeout.current = setTimeout(async () => {
      try {
        const response = await fetch(
          `https://dummyjson.com/recipes/search?q=${query}`
        );
        const data = await response.json();
        onRecipesFetched(data.recipes || []);
      } catch (error) {
        console.error("Error fetching recipes:", error);
      }
      setLoading(false);
    }, 500);

    return () => clearTimeout(debounceTimeout.current);
  }, [query]);

  return (
    <div className="w-full max-w-md mx-auto bg-gray-200">
      <input
        type="text"
        placeholder="Search recipes..."
        className="w-full p-2 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      {loading && <p className="text-sm text-gray-500">Loading...</p>}
    </div>
  );
};

export default SearchBar;
