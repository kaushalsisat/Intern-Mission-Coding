import FAQ from "./components/FAQ";

 

function App() {
  return (
    <div>
      <FAQ/>
    </div>
  );
}

export default App;
